from flask import Flask, render_template, request

hr = Flask(__name__)

@hr.route('/')
def helloworld():
    return render_template("index.html")

if __name__ == '__main__':
    hr.run(debug=False, port=8000)
